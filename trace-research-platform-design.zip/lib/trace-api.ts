export type ResearchScope = 'web' | 'papers' | 'both'
export type ResearchDepth = 'quick' | 'standard' | 'deep'

export type ApiError = { message: string; status?: number; code?: string }

export type ResearchSession = {
  id: string
  question: string
  status: 'pending' | 'running' | 'completed' | 'failed'
  createdAt?: string
}

export type WorkflowEvent = {
  event: string
  stage?: string
  status?: string
  message?: string
  data?: unknown
  timestamp?: string
}

const API_BASE_URL = (process.env.NEXT_PUBLIC_TRACE_API_URL ?? 'http://localhost:8000').replace(/\/$/, '')
const REQUEST_TIMEOUT_MS = 20_000

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const controller = new AbortController()
  const timeout = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS)
  try {
    const response = await fetch(`${API_BASE_URL}${path}`, {
      ...init,
      headers: { Accept: 'application/json', 'Content-Type': 'application/json', ...init?.headers },
      signal: controller.signal,
    })
    const body = await response.json().catch(() => null)
    if (!response.ok) throw { message: body?.detail ?? body?.message ?? `Request failed (${response.status})`, status: response.status } satisfies ApiError
    return body as T
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') throw { message: 'The TRACE backend timed out. Try again.' } satisfies ApiError
    if (typeof error === 'object' && error && 'message' in error) throw error
    throw { message: 'TRACE backend is unavailable. Check your connection and API URL.' } satisfies ApiError
  } finally { window.clearTimeout(timeout) }
}

export const traceApi = {
  baseUrl: API_BASE_URL,
  createResearch(input: { question: string; depth: ResearchDepth; scope: ResearchScope }) {
    return request<ResearchSession>('/api/research', { method: 'POST', body: JSON.stringify(input) })
  },
  getResearch(id: string) { return request<ResearchSession>(`/api/research/${encodeURIComponent(id)}`) },
  getReport(id: string) { return request<unknown>(`/api/research/${encodeURIComponent(id)}/report`) },
  streamResearch(id: string, onEvent: (event: WorkflowEvent) => void, onError: (error: ApiError) => void) {
    const source = new EventSource(`${API_BASE_URL}/api/research/${encodeURIComponent(id)}/events`)
    source.onmessage = (message) => { try { onEvent(JSON.parse(message.data) as WorkflowEvent) } catch { onError({ message: 'Received an invalid event from TRACE.' }) } }
    source.onerror = () => { onError({ message: 'The event stream disconnected.' }); source.close() }
    return () => source.close()
  },
}
