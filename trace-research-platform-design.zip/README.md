# TRACE frontend

TRACE is an evidence-first research intelligence frontend built with Next.js App Router, React, TypeScript, Tailwind CSS v4, and pnpm.

## Run locally

```bash
pnpm install
cp .env.example .env.local
pnpm dev
```

Open http://localhost:3000.

## Backend configuration

Set `NEXT_PUBLIC_TRACE_API_URL` to the FastAPI base URL (for example `http://localhost:8000`). The typed service layer in `lib/trace-api.ts` keeps endpoint assumptions isolated. It currently expects `POST /api/research`, `GET /api/research/:id`, `GET /api/research/:id/report`, and an SSE stream at `GET /api/research/:id/events`; adjust those paths there to match the existing LangGraph API contract.

When the backend is unavailable, the existing preview remains clearly labelled as an event-driven preview and does not claim that a real run completed.

## Export

Download the project ZIP from the v0 project menu or sync the project to GitHub. No preview-only assets or secrets are required.
